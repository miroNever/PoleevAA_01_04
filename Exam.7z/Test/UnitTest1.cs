using Exam;

namespace Test
{
    public class Tests
    {

        [Test]
        public void CheckQ()
        {
            Computer computer = new("Amd", 2.1, 8000);
            Assert.That(computer.Q(), Is.EqualTo(8000.63));
        }
        [Test]
        public void CheckSecondQ()
        {
            SecondClass secondClass =new (512, "Intel", 4.1, 12000);
            Assert.That(secondClass.Q(), Is.EqualTo(12001.23));
        }
        [Test]
        public void CheckSecondQr()
        {
            SecondClass secondClass =new (512, "Intel", 4.1, 12000);
            Assert.That(secondClass.Qr(), Is.EqualTo(12257.23));
        }
        public void CheckP()
        {
            SecondClass secondClass =new (-1, "Intel", 4.1, 12000);
            Assert.That(secondClass.Qr(), Is.EqualTo(0));
        }
    }
}