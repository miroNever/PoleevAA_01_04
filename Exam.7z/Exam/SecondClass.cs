﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exam
{
    public class SecondClass : Computer
    {
        double P;
        public SecondClass(double p, string nameCPU, double clockfrequency, int amountOfRAM) : base(nameCPU, clockfrequency, amountOfRAM)
        {
            P = p;
        }
        public override void Info()
        {
            base.Info();
            Console.WriteLine("Обьем накопителя: " + P);
        }
        public double Qr()
        {
            if (P < 0)
                return 0;
            if (P > 500)
                return Q() + 0.5 * P;
            else 
                return Q() + 1.5 * P;
        }
    }
}
