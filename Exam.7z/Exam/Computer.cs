﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exam
{
    public class Computer
    {
        string NameCPU;
        double ClockFrequency;
        double AmountOfRAM;

        public Computer(string nameCPU, double clockfrequency, int amountOfRAM)
        {
            NameCPU = nameCPU;
            ClockFrequency = clockfrequency;
            AmountOfRAM = amountOfRAM;
        }
        public virtual void Info()
        {
            Console.WriteLine("Название процессора: " + NameCPU);
            Console.WriteLine("Частота процессора: " + ClockFrequency);
            Console.WriteLine("Обьем оперативной памяти: " + AmountOfRAM);
        }
        public double Q()
        {
            return (0.3 * ClockFrequency) + AmountOfRAM;
        }

    }
}
