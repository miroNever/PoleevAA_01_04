﻿using Exam;

Computer computer = new("AMD 5", 2.4, 16000);
computer.Info();
Console.WriteLine($"Результат расчета по формуле Q: {computer.Q()}");
SecondClass secondcomputer = new(1000, "Intel 5", 2.6, 32000);
secondcomputer.Info();
Console.WriteLine($"Результат расчета по формуле Q: {secondcomputer.Q()}");
Console.WriteLine($"Результат расчета по формуле Qr: {secondcomputer.Qr()}");
